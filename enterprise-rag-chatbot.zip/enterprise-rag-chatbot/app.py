import streamlit as st 
 
from langchain_chroma import Chroma 
from langchain_huggingface import HuggingFaceEmbeddings 
from langchain_ollama import OllamaLLM 
 
 
# Page title 
st.title("Enterprise RAG Chatbot") 
 
 
# 1. Load embedding model 
embeddings = HuggingFaceEmbeddings( 
    model_name="sentence-transformers/all-MiniLM-L6-v2" 
) 
 
 
# 2. Load existing Chroma database 
vectorstore = Chroma( 
    persist_directory="chroma_db", 
    embedding_function=embeddings 
) 
 
 
# 3. Create retriever 
retriever = vectorstore.as_retriever( 
    search_kwargs={"k": 3} 
) 
 
 
# 4. Load local LLM 
llm = OllamaLLM( 
    model="mistral" 
) 
 
 
# 5. Get user question 
question = st.chat_input("Ask your question") 
 
 
if question: 
 
    # Retrieve relevant documents 
    documents = retriever.invoke(question) 
 
 
    # Combine retrieved text 
    context = "\n\n".join( 
        document.page_content 
        for document in documents 
    ) 
 
 
    # Prompt 
    prompt = f""" 
You are an enterprise assistant. 
 
Answer the question using only the provided context. 
 
Context: 
{context} 
 
Question: 
{question} 
 
Answer: 
""" 
 
 
    # Generate answer 
    answer = llm.invoke(prompt) 
 
 
    # Display answer 
    st.write(answer)